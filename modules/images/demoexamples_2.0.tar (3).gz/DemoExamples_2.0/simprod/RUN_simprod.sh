#!/bin/bash
# product version 1.2
# Initial version: Aug 2016
# Mar 2017: Scripts reformatted for better consistency between tests
# Dec 2017: TigerGraph v1.1: Added option to run with JSON api 1.0 or 2.0
# Mar 2018: TigerGraph v1.2: Specify a graph when running gsql commands

### EDIT: Customize the name of the test.
test='simprod'

##########################################
### This middle section of the file is the same for every test ###

current_date_time="`date "+%Y-%m-%d %H:%M:%S"`";
echo "*** Started $0 at $current_date_time" | tee $test$1.log
START=$(date +%s)
###
gsql 'DROP ALL'
gsql ../${test}/${test}_model.gsql
gsql 'CREATE GRAPH gsql_demo(*)'

SCHEMA_END=$(date +%s)
echo "*** Elapsed schema creation time = $(($SCHEMA_END- $START)) sec" | tee -a $test$1.log
###
## CLEAR GRAPH and INIT GRAPH no longer needed in 0.8
gsql -g gsql_demo ../${test}/${test}_load.gsql

LOAD_END=$(date +%s)
echo "*** Elapsed loading time = $(($LOAD_END - $SCHEMA_END)) sec" | tee -a $test$1.log
##########################################
### Query section: Customize the name(s) of the query and the query arguments

gsql -g gsql_demo ../${test}/${test}_query.gsql

gsql -g gsql_demo 'INSTALL QUERY productSuggestion'
QUERY_END=$(date +%s)
echo "*** Elapsed install query time = $(($QUERY_END - $LOAD_END)) sec" | tee -a $test$1.log

q='RUN QUERY productSuggestion ("62abcax334", 1, 3)'
echo $q; gsql -g gsql_demo $q

END=$(date +%s)
echo "*** Total elapsed time = $(($END - $START)) sec" | tee -a $test$1.log
