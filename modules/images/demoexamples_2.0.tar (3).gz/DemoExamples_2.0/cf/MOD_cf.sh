#!/bin/bash
# Product version 1.2: Use the gsql -g option to specify the graph name.

echo "*** Initial State ***"
echo "*** Show all User vertices and all Edges starting from User id2 ***"
gsql -g gsql_demo cf_mod_check.gsql

echo "*** Modification 1: Delete User id3 ***"
gsql -g gsql_demo cf_mod1.gsql
sleep 1s
gsql -g gsql_demo cf_mod_check.gsql

echo "*** Modification 2: Add an attribute to User vertices and the Liked edges ***"
gsql -g gsql_demo cf_mod2.gsql
sleep 1s
gsql -g gsql_demo cf_mod_check.gsql

echo "*** Modification 3: Insert some values to new attributes ***"
gsql -g gsql_demo cf_mod3.gsql
sleep 1s
gsql -g gsql_demo cf_mod_check.gsql
