#!/bin/bash
cd `dirname $0`

##############################################################
# RUN_DEMO.sh
# product version 1.2
# Initial version: Aug 2016
# Mar 2017: Scripts reformatted for better consistency between tests
# Dec 2017: TigerGraph v1.1: Added option to run with JSON api 1.0 or 2.0
# Mar 2018: TigerGraph v1.2: Specify a graph when running gsql commands
#
# Use a modular template to make it easy to swap/add tests
#############################################################
comment_out_line(){
  if [ "$#" != 3 ]; then
    echo "Usage: $0 comment/uncomment expression_string file_name"
    return
  fi
  comment="$1"
  expression_string="$2"
  file_name="$3"
  if [ "$comment" = "comment" ]; then
    # comment out line
    sed -i "s/ $expression_string/ #$expression_string/g" $file_name
  else
    # uncomment line
    sed -i "s/#\+$expression_string/$expression_string/g" $file_name
  fi
}

current_date_time="`date "+%Y-%m-%d %H:%M:%S"`";
echo "*** Started $0 at $current_date_time" | tee demo$1.log
START=$(date +%s)
##########################################
echo
echo "*** STEP 0: Start gsql server"
# Check if gsql started
if gsql -v &>/dev/null; then
  echo "[OK] gsql server already start."
else
  gadmin start
fi

# Get JSON API version
json_api_version=$(gsql ls 2>/dev/null | grep "Json API version:" | awk -F ': ' '{print $2}')
if [ "$json_api_version" = "v2" ]; then
  comment_out_line "comment"   "PRINT AllV.page_id, AllV.@score;"          ../pagerank/pagerank_query.gsql
  comment_out_line "uncomment" "PRINT AllV\[AllV.page_id, AllV.@score\];" ../pagerank/pagerank_query.gsql
  comment_out_line "comment"   "PRINT L2.@score;"                          ../people/people_query.gsql
  comment_out_line "uncomment" "PRINT L2 \[L2.@score\];"                   ../people/people_query.gsql
else
  # JSON API version v1
  comment_out_line "uncomment" "PRINT AllV.page_id, AllV.@score;"          ../pagerank/pagerank_query.gsql
  comment_out_line "comment"   "PRINT AllV\[AllV.page_id, AllV.@score\];" ../pagerank/pagerank_query.gsql
  comment_out_line "uncomment" "PRINT L2.@score;"                          ../people/people_query.gsql
  comment_out_line "comment"   "PRINT L2 \[L2.@score\];"                   ../people/people_query.gsql
fi
##########################################
echo
echo "*** STEP 1: Create the graph schema"
#1A. Clear the catalog (erases graph schema, loading jobs, and queries.
# In Platform 0.8+, this also clears the graph store.
gsql 'DROP ALL'

#1B. Create the vertex and edge types (1 line per demo example)
gsql ../cf/cf_model.gsql
gsql ../pagerank/pagerank_model.gsql
gsql ../simprod/simprod_model.gsql
gsql ../name/name_model.gsql
gsql ../video/video_model.gsql
gsql ../people/people_model.gsql
gsql ../social/social_model.gsql

gsql 'CREATE GRAPH gsql_demo(*)'

SCHEMA_END=$(date +%s)
echo "*** Elapsed schema creation time = $(($SCHEMA_END- $START)) sec" | tee -a demo$1.log
#############################################################
echo
echo "*** STEP 2: Load data"
#2A. Clear and initialize the graph store (global, takes about 1 minute)
## CLEAR GRAPH and INIT GRAPH no longer needed in 0.8
#gsql 'CLEAR GRAPH STORE -HARD'
#gsql 'INIT GRAPH STORE FOR GRAPH gsql_demo'

#2B. Define loading jobs and load data (1 line per demo example)
gsql -g gsql_demo ../cf/cf_load.gsql
gsql -g gsql_demo ../pagerank/pagerank_load.gsql
gsql -g gsql_demo ../simprod/simprod_load.gsql
gsql -g gsql_demo ../name/name_load.gsql
gsql -g gsql_demo ../video/video_load.gsql
gsql -g gsql_demo ../people/people_load.gsql
gsql -g gsql_demo ../social/social_load.gsql

LOAD_END=$(date +%s)
echo "*** Elapsed loading time = $(($LOAD_END - $SCHEMA_END)) sec" | tee -a demo$1.log
##########################################
echo
echo "*** STEP 3: Create, install, and run queries"
#3A. Define queries (instant, 1 line per demo example)
gsql -g gsql_demo ../cf/cf_query.gsql
gsql -g gsql_demo ../pagerank/pagerank_query.gsql
gsql -g gsql_demo ../simprod/simprod_query.gsql
gsql -g gsql_demo ../name/name_query.gsql
gsql -g gsql_demo ../video/video_query.gsql
gsql -g gsql_demo ../people/people_query.gsql
gsql -g gsql_demo ../social/social_query.gsql

#3B. Install queries (takes 1 to 2 minutes)
gsql -g gsql_demo 'INSTALL QUERY *'

QUERY_END=$(date +%s)
echo "*** Elapsed install query time = $(($QUERY_END - $LOAD_END)) sec" | tee -a demo$1.log
##########################################
#3C. Run queries
while read line; do
   echo $line;
   gsql -g gsql_demo $line;
done < demo_queries.gsql

END=$(date +%s)
echo "*** Total elapsed time = $(($END - $START)) sec" | tee -a demo$1.log
