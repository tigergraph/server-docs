curl -X GET 'http://localhost:9000/query/gsql_demo/topCoLiked?input_user=id1&topk=20'
curl -X GET 'http://localhost:9000/query/gsql_demo/pageRank?maxChange=0.001&maxIteration=100&dampingFactor=0.15'
curl -X GET 'http://localhost:9000/query/gsql_demo/productSuggestion?seed=62abcax334&threshold_cnt=1&k=3'
curl -X GET 'http://localhost:9000/query/gsql_demo/namesSimilar?seed=0&firstName=michael&lastName=jackson&k=100'
curl -X GET 'http://localhost:9000/query/gsql_demo/videoRecommendation?seed=0&n=10&k=10'
curl -X GET 'http://localhost:9000/query/gsql_demo/peopleYouMayKnow?startP=1&TopK=10'
curl -X GET 'http://localhost:9000/query/gsql_demo/socialFromUser?uid=0&is_active=true&reg_time_min=0&reg_time_max=147000000&k=10'
curl -X GET 'http://localhost:9000/query/gsql_demo/socialToUser?uid=4&is_active=true&reg_time_min=0&reg_time_max=150000000&K=10'
curl -X GET 'http://localhost:9000/query/gsql_demo/socialMutualConnections?uid1=1&uid2=7&is_active=false&reg_time_min=0&reg_time_max=2000000000&k=10'
curl -X GET 'http://localhost:9000/query/gsql_demo/socialOneWay?mutual_contacts_min=1&mutual_contacts_max=10'

# Do not delete this line. Need an extra line after the last query

